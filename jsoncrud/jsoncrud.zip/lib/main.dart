import 'package:crud/productview.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MaterialApp(home:ProductViewScreeen()));
}