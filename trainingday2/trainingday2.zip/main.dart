import 'package:flutter/material.dart';
import 'componentex.dart';

void main()
{
  runApp(CustomComponentsApp());
}