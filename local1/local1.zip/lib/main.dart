
import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';

void main()
{
  runApp(MyApp());
}

mixin AppLocale
{
  static const String title = 'title';
  static const String thisIs = 'thisIs';

  static const Map<String, dynamic> EN =
  {
    title: 'Localization',
    thisIs: 'This is %a package, version %a.',
  };
  // static const Map<String, dynamic> KM =
  // {
  //   title: 'ការធ្វើមូលដ្ឋានីយកម្ម',
  //   thisIs: 'នេះគឺជាកញ្ចប់%a កំណែ%a.',
  // };
  static const Map<String, dynamic> GU =
  {
    title: 'ગુજરાતી',
    thisIs: 'પીજીવીસીએલમાં આપનું સ્વાગત છે.',
  };

  static const Map<String, dynamic> JA =
  {
    title: 'ローカリゼーション',
    thisIs: 'これは%aパッケージ、バージョン%aです。',
  };
}


class MyApp extends StatefulWidget
{
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp>
{
  final FlutterLocalization _localization = FlutterLocalization.instance;

  @override
  void initState()
  {
    // TODO: implement initState
    // super.initState();

    _localization.init
      (
        mapLocales:
        [
          const MapLocale
            (
            'en',
            AppLocale.EN,
            countryCode: 'US',
            fontFamily: 'Font EN',
          ),
          // const MapLocale
          //   (
          //   'km',
          //   AppLocale.KM,
          //   countryCode: 'KH',
          //   fontFamily: 'Font KM',
          // ),
          const MapLocale
            (
            'gu',
            AppLocale.GU,
            countryCode: 'IN',
            fontFamily: 'Font GU',
          ),

          const MapLocale(
            'ja',
            AppLocale.JA,
            countryCode: 'JP',
            fontFamily: 'Font JA',
          ),
        ],
        initLanguageCode: 'en');
    _localization.onTranslatedLanguage = _onTranslatedLanguage;
  }

  void _onTranslatedLanguage(Locale? locale)
  {
    setState(() {});
  }


  @override
  Widget build(BuildContext context)
  {
    return MaterialApp
      (
      supportedLocales: _localization.supportedLocales,
      localizationsDelegates: _localization.localizationsDelegates,
      home:SettingsScreen(),
      theme: ThemeData(fontFamily: _localization.fontFamily),
    );
  }
}
class SettingsScreen extends StatefulWidget
{
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen>
{
  final FlutterLocalization _localization = FlutterLocalization.instance;

  @override
  Widget build(BuildContext context)
  {
    return Scaffold
      (
      appBar: AppBar(title: Text("Flutter Localization"),),
      body: Container
        (
        padding: const EdgeInsets.all(16.0),
        child: Column
          (
          children:
          [

            Row
              (
              children:
              [
                Expanded(
                  child: ElevatedButton(
                    child: const Text('English'),
                    onPressed: () {
                      _localization.translate('en');
                    },
                  ),
                ),
                // const SizedBox(width: 16.0),
                // Expanded(
                //   child: ElevatedButton(
                //     child: const Text('ភាសាខ្មែរ'),
                //     onPressed: () {
                //       _localization.translate('km');
                //     },
                //   ),
                // ),
                const SizedBox(width: 16.0),
                Expanded(
                  child: ElevatedButton(
                    child: const Text('ગુજરાતી1'),
                    onPressed: () {
                      _localization.translate('gu');
                    },
                  ),
                ),


                const SizedBox(width: 16.0),
                Expanded(
                  child: ElevatedButton(
                    child: const Text('日本語'),
                    onPressed: () {
                      _localization.translate('ja', save: false);
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16.0),


            ItemWidget(
              title: 'Current Language',
              content: _localization.getLanguageName(),
            ),
            ItemWidget(
              title: 'Font Family',
              content: _localization.fontFamily,
            ),
            ItemWidget(
              title: 'Locale Identifier',
              content: _localization.currentLocale.localeIdentifier,
            ),
            ItemWidget(
              title: 'String Format',
              content: Strings.format(
                'Hello %a, this is me %a.',
                ['Dara', 'Sopheak'],
              ),
            ),
            ItemWidget(
              title: 'Context Format String',
              content: context.formatString(
                AppLocale.thisIs,
                [AppLocale.title, 'LATEST'],
              ),
            ),

          ],
        ),





      ),
    );
  }
}
class ItemWidget extends StatelessWidget {
  const ItemWidget({
    super.key,
    required this.title,
    required this.content,
  });

  final String? title;
  final String? content;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: Text(title ?? '')),
          const Text(' : '),
          Expanded(child: Text(content ?? '')),
        ],
      ),
    );
  }
}
